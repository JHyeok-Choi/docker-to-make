var state_check = false;

let audioIN = { audio: true };

navigator.mediaDevices.getUserMedia(audioIN)
.then(function (mediaStreamObj) {
	let audio = document.querySelector('audio');

	if ("srcObject" in audio) {
	audio.srcObject = mediaStreamObj;
	}
	else {
	audio.src = window.URL
		.createObjectURL(mediaStreamObj);
	}

	audio.onloadedmetadata = function (ev) {
	audio.play();
	};

	let start = document.getElementById('btnStart');
	let stop = document.getElementById('btnStop');

	let playAudio = document.getElementById('audioPlay');

	let mediaRecorder = new MediaRecorder(mediaStreamObj);
	MediaRecorder.isTypeSupported("audio/wav;codecs=MS_PCM")

	start.addEventListener('click', function (ev) {
		if (state_check) {
			mediaRecorder.stop();
			state_check = false;
		} else {
			mediaRecorder.start();
			state_check = true;
		}
	})

	mediaRecorder.ondataavailable = function (ev) {
	dataArray.push(ev.data);
	}
	
	let dataArray = [];

	mediaRecorder.onstop = function (ev) {

	let audioData = new Blob(dataArray, 
				{ 'type' : 'audio/wav; codecs=MS_PCM' });
	
	dataArray = [];

	let audioSrc = window.URL
		.createObjectURL(audioData);

	var formData = new FormData();
	formData.append('file', audioData)


    // let furl = fetch("/url", {method:"GET"})
    // .then((data) => {return data.json()})
    // console.log(furl);

    fetch("/url", {method:"GET"})
    .then(response => response.json())
    .then((data0) => {
        
        const chn = document.getElementById("inner");
	    let useFetch = (url=data0.url, method='POST') => {
		return fetch(url, {
			method: 'POST',
			body: formData,
		})
		.then((data) => data.json())
		.then((res) => (chn.innerHTML += 
			`<li class="log">${res.date}&emsp;${res.label}&emsp;${res.dB}dB</li>`,
			chn.scrollTop = chn.scrollHeight))
		.catch((error) => {
			return console.log(new Error(error));
		});
	};

	useFetch();
    setInterval(useFetch, 5300);
    })

	playAudio.src = audioSrc;
	}
})
.catch(function (err) {
	console.log(err.name, err.message);
});

